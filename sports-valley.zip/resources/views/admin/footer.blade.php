<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      
      <div class="row">
        <div class="col-md-8 col-sm-6 col-xs-12">
          <p class="copyright-text">Copyright &copy; <script>document.write(new Date().getFullYear());</script> All Rights Reserved by 
            <a href="https://nahid-limu.github.io/" target="_blank" data-toggle="tooltip" data-placement="top" title="Click To See Portfolio">Nahid Limu</a>.
          </p>
        </div>

        
        <div class="row col-md-4 col-sm-6 col-xs-12">
            <div class="col-md-4"><a class="facebook" href="https://web.facebook.com/nahidlimu" target="_blank" data-toggle="tooltip" data-placement="top" title="Get Me In facebook"><i class="fab fa-facebook-square" style="font-size: 25px;"></i></a></div>
            <div class="col-md-4"><a class="linkedin" href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Get Me In linkedin"><i class="fab fa-linkedin-in" style="font-size: 25px;"></i></a></div>
            <div class="col-md-4"><a class="twitter" href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Get Me In twitter"><i class="fab fa-twitter" style="font-size: 25px;"></i></a></div>
        </div>
      </div>
    </div>
  </div>
</footer>