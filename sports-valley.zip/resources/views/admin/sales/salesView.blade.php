@extends('layouts.appAdmin')
@section('title', 'Sales')
@section('css')

@endsection

@section('content')



<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Content Row -->
  <div class="row">

    
  </div>

  <!-- Content Row -->

  <!-- Content Row  details-->
  <div class="row">


  </div>

  

</div>

@endsection

@section('script')
// <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
@endsection