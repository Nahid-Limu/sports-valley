@extends('layouts.app')
@section('title', 'Home')
@section('css')

@endsection
@section('content')

Defult Home
		
		
@endsection

