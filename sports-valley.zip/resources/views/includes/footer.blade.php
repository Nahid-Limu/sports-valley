<footer id="colorlib-footer" role="contentinfo">
  <div class="container">
    <div class="row row-pb-md">
      <div class="col footer-col colorlib-widget">
        <h4>About Sports-Valley</h4>
        <p>
          SPORTS VALLEY is a Platfrom Where We Provide Sports Accessories, Sports Good, Sports Wear, Fitness Equipment and Other Sports related product.
          We Provide our Customers with the best Satisfaction for Sustainable competivtive advantage.
        </p>
        <p>
          <ul class="colorlib-social-icons">
            <li><a href="#"><i class="icon-twitter"></i></a></li>
            <li><a href="#"><i class="icon-facebook"></i></a></li>
            <li><a href="#"><i class="icon-linkedin"></i></a></li>
            <li><a href="#"><i class="icon-dribbble"></i></a></li>
          </ul>
        </p>
      </div>
      {{-- <div class="col footer-col colorlib-widget">
        <h4>Customer Care</h4>
        <p>
          <ul class="colorlib-footer-links">
            <li><a href="#">Contact</a></li>
            <li><a href="#">Returns/Exchange</a></li>
            <li><a href="#">Gift Voucher</a></li>
            <li><a href="#">Wishlist</a></li>
            <li><a href="#">Special</a></li>
            <li><a href="#">Customer Services</a></li>
            <li><a href="#">Site maps</a></li>
          </ul>
        </p>
      </div> --}}
      {{-- <div class="col footer-col colorlib-widget">
        <h4>Information</h4>
        <p>
          <ul class="colorlib-footer-links">
            <li><a href="#">About us</a></li>
            <li><a href="#">Delivery Information</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Support</a></li>
            <li><a href="#">Order Tracking</a></li>
          </ul>
        </p>
      </div> --}}

      {{-- <div class="col footer-col">
        <h4>News</h4>
        <ul class="colorlib-footer-links">
          <li><a href="blog.html">Blog</a></li>
          <li><a href="#">Press</a></li>
          <li><a href="#">Exhibitions</a></li>
        </ul>
      </div> --}}

      <div class="float-left">
        <h4>Contact Information</h4>
        <ul class="colorlib-footer-links">
          <li><i class="icon-shop"></i> Cinema Hall Road, <br>    Hazi Ibrahim Market, Panchagarh</li>
          <li><i class="icon-phone"></i><a href="tel://01625836160"> +88 01625836160</a></li>
          <li><i class="icon-mail"></i><a href="mailto:info@yoursite.com"> info@sports-valley.net</a></li>
          <li><i class="icon-home"></i><a href="#"> sports-valley.net</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="copy">
    <div class="row">
      <div class="col-sm-12 text-center">
        <p>
          <span><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | 
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></span> 
          <span class="block">Developed by --<a href="https://www.facebook.com/nahidlimu" target="_blank">Nahid Limu</a></span>
        </p>
      </div>
    </div>
  </div>
</footer>