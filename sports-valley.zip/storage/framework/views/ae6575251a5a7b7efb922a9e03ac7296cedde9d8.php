<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('css'); ?>
<style>

    /* Make the image fully responsive */
    .carousel-inner img {
        width:740px;
        height:360px;
    }

    .carousel-indicators li {
    background-color:aqua;
    }
    .carousel-indicators .active {
        background-color: #fa0000;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div id="page">

    <div class="breadcrumbs bg-warning">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="bread"><span><a href="<?php echo e(route('home')); ?>">Home</a></span> / <span>Category Details</span> / <span>All Products</span> / <span>Product Details</span></p>
                </div>
            </div>
        </div>
    </div>


    <div class="colorlib-product">
        <div class="container">
            <div class="row row-pb-lg product-detail-wrap">
                <div class="col-sm-8">
                    <div id="demo" class="carousel slide" data-ride="carousel">

                        <!-- Indicators -->
                        <ul class="carousel-indicators">
                          <li data-target="#demo" data-slide-to="0" class="active"></li>
                          <li data-target="#demo" data-slide-to="1"></li>
                          <li data-target="#demo" data-slide-to="2"></li>
                        </ul>
                        
                        <!-- The slideshow -->
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php echo e(($key == 0 ) ? "active" : ""); ?> ">
                                    <img src="<?php echo e(asset('product_img').'/'.$image); ?>" class="img-fluid">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <!-- Left and right controls -->
                        <a class="carousel-control-prev" href="#demo" data-slide="prev" >
                          <span class="carousel-control-prev-icon"></span>
                        </a>
                        <a class="carousel-control-next" href="#demo" data-slide="next">
                          <span class="carousel-control-next-icon"></span>
                        </a>
                      </div>
                </div>
                <div class="col-sm-4 bg-warning">
                    <div class="product-desc">
                        <br>
                        <table class="table table-sm table-bordered table-light">
                            <tbody>
                                <tr>
                                    <kbd class="d-flex justify-content-center">Details</kbd>
                                  </tr>
                              <tr>
                                <td colspan="2"><kbd>Product Name:</kbd></td>
                                <td><h5><?php echo e($product->name); ?></h5></td>
                              </tr>
                              <tr>
                                <td colspan="2"><kbd>Brand:</kbd></td>
                                <td><h5><?php echo e($product->barnd); ?></h5></td>
                              </tr>
                              <tr>
                                <td colspan="2"><kbd>Price:</kbd></td>
                                <td><h5><?php echo e($product->selling_price); ?>Tk</h5></td>
                              </tr>
                              <tr>
                                <td colspan="2"><kbd>In Stock:</kbd></td>
                                <td><h5><?php echo e($product->quantity); ?> piece</h5></td>
                              </tr>
                            </tbody>
                          </table>
                        <br>
                        <p>
                            
                            
                        </p>
                        
                        
                        <div class="row">
                            <div class="col-sm-12 text-center">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="row">
                        <div class="col-md-12 pills">
                            <div class="bd-example bd-example-tabs">
                              <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">

                                <li class="nav-item">
                                  <a class="nav-link active" id="pills-description-tab" data-toggle="pill" href="#pills-description" role="tab" aria-controls="pills-description" aria-expanded="true">Full Description</a>
                                </li>
                                
                              </ul>

                              <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane border fade show active" id="pills-description" role="tabpanel" aria-labelledby="pills-description-tab">
                                        <div class="col-md-6"> 
                                            <div class="desc-title">
                                                
                                                <span class="text-success">Description:</span>
                                                <p><?php echo e($product->product_description); ?></p>
                                            </div>
                                        </div>
                                    </div>

                                    

                                    
                              </div>
                            </div>
                     </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>