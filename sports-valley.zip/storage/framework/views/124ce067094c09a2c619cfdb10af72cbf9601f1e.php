<?php $__env->startSection('title', 'All Category'); ?>
<?php $__env->startSection('css'); ?>
<style>

  /* Make the image fully responsive */
  /* .carousel-inner img {
    width: 100%;
    height: 100%;
  } */
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div id="page">

    <div class="breadcrumbs bg-warning">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="bread"><span><a href="<?php echo e(route('home')); ?>">Home</a></span> / <span>Category Details</span></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="colorlib-featured">
        <div class="container">
            <?php if(count($cat_details)): ?>
                <div class="row">
                    <?php $__currentLoopData = $cat_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4 text-center">
                            <div class="featured">
                                <div class="featured-img featured-img-2" style="background-image: url(  <?php echo e(asset('category_product_img').'/'.$cd->image); ?>  );">
                                    <h2 class="font-weight-bold" style="color: aqua"> <?php echo e($cd->cat_product); ?> </h2>
                                    <p><a href="<?php echo e(route('allProducts', [base64_encode($cd->id)] )); ?>" class="btn btn-primary btn-md">Click To See All</a></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <h1 class="text-danger font-italic d-flex justify-content-center">Sorry No Product available</h1>
            <?php endif; ?>
            <span class="d-flex justify-content-center"><?php echo e($cat_details->links()); ?></span>
        </div>
    </div>

    <div class="colorlib-partner">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 offset-sm-2 text-center colorlib-heading colorlib-heading-sm">
                    <h2>Brandes We Provide</h2>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $Brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($Brand->id==99): ?>
                        <?php continue; ?>
                    <?php endif; ?>
                    <div class="col partner-col text-center">
                        <img src="<?php echo e(asset('images').'/'.$Brand->image); ?>" class="img-fluid" alt="Free html4 bootstrap 4 template">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>