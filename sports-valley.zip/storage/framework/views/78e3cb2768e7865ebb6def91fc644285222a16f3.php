<nav class="colorlib-nav" role="navigation">
  <div class="top-menu">
    <div class="container ">
      <div class="row">
        <div class="col-sm-7 col-md-9">
          <div id="colorlib-logo"><a href="<?php echo e(route('home')); ?>">Sports Valley</a></div>
          <span class="text-danger">Let's play The Game</span>
        </div>
        <div class="col-sm-5 col-md-3">
              <form action="#" class="search-wrap">
                 <div class="form-group">
                    <input type="search" class="form-control search" placeholder="Search">
                    <button class="btn btn-primary submit-search text-center" type="submit"><i class="icon-search"></i></button>
                 </div>
              </form>
           </div>
         </div>
      <div class="row">
        <div class="col-sm-12 text-left menu-1">
          <ul>
            <li class="active"><a href="<?php echo e(route('home')); ?>">Home</a></li>
            
            <?php
                $Business= App\BusinessCategory::get();
            ?>
            <?php $__currentLoopData = $Business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(route('categoryDetails', [base64_encode($b->id)])); ?>"><?php echo e($b->cat_name); ?></a></li>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact Us</a></li>
            <li class="cart"><a href="cart.html"><i class="icon-shopping-cart"></i> Cart [0]</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  
</nav>