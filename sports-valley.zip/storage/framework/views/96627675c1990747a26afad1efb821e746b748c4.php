<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('css'); ?>
<style>
	.fixed-img-size {
		width: 200px; 
		height: 200px;
		margin-top: 20px;
    	/* object-fit: cover; */
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">

    <div id="page">
		
		
		<div class="colorlib-intro">
			<div class="col-sm-8 offset-sm-2 text-center colorlib-heading colorlib-heading-sm">
				<h2>Business Category</h2>
			</div>

			<div class="row bg-warning text-dark">
				
				<?php $__currentLoopData = $Business; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col partner-col text-center">
						<a href="<?php echo e(route('categoryDetails', [base64_encode($b->id)])); ?>"><img src="<?php echo e(asset('system_img').'/'.$b->image); ?>" class="img-fluid rounded-circle" alt="Free html4 bootstrap 4 template">
						<span class="text-center "> <kbd><?php echo e($b->cat_name); ?></kbd> </span> </a> 
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</div>

		</div>

		<div class="colorlib-product">
			<div class="container">

				<?php $__currentLoopData = $mainArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(count($value)): ?>
					<h2 class="text-center text-info "><kbd class="bg-info text-dark font-italic"><?php echo e($value[0]->cat_name); ?></kbd></h2>
					
					<div class="row row-pb-md">
						<div class="w-100"></div>
						<?php $count = 0; ?>
						<?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php if($count == 4): ?>
								<?php break; ?>
							<?php endif; ?>
						
							<div class="col-lg-3 mb-4 text-center">
								<div class="product-entry border">
									<a href="<?php echo e(route('allProducts', [base64_encode($v->id)] )); ?>" class="prod-img">
										<img src="<?php echo e(asset('category_product_img').'/'.$v->image); ?>" class="img-fluid fixed-img-size" alt="Free html5 bootstrap 4 template">
									</a>
									<div class="desc">
										<h2 class="text-uppercase"><a href="#"><?php echo e($v->cat_product); ?></a></h2>
										
										<span class="price bg-success">In Stock <?php echo e($v->quantity); ?> piece</span>
									</div>
								</div>
							</div>
							<?php $count++; ?>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<span style="margin-left: 20px"><a href="<?php echo e(route('categoryDetails', [base64_encode($value[0]->bc_id)])); ?>" class="btn btn-primary btn-sm">See More </a></span>
					</div>
					
					
					<?php endif; ?>
					<?php continue; ?>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>

		</div>

		<div class="colorlib-partner">
			<div class="container">
				<div class="row">
					<div class="col-sm-8 offset-sm-2 text-center colorlib-heading colorlib-heading-sm">
						<h2>Brandes We Provide</h2>
					</div>
				</div>
				<div class="row">
					
					<?php $__currentLoopData = $Brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($Brand->id==99): ?>
						<?php continue; ?>
					<?php endif; ?>
						<div class="col partner-col text-center">
							<img src="<?php echo e(asset('images').'/'.$Brand->image); ?>" class="img-fluid" alt="Free html4 bootstrap 4 template">
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>
		</div>

		
	</div>
	
    
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>