<?php $__env->startSection('title', 'All Brands Product'); ?>
<?php $__env->startSection('css'); ?>
<style>

  /* Make the image fully responsive */
  /* .carousel-inner img {
    width: 100%;
    height: 100%;
  } */

  .product_img {
    width: 250px;
    height: 250px;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div id="page">

    <div class="breadcrumbs bg-warning">
        <div class="container">
            <div class="row">
                <div class="col">
                    <p class="bread"><span><a href="<?php echo e(route('home')); ?>">Home</a></span> / <span>Category Details</span> / <span>All Products</span></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="colorlib-featured">
        <div class="container">
           
            <div class="row row-pb-md">
                <div class="w-100"></div>
                <?php if(count($products)): ?>
                    
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 mb-4 text-center">
                            <div class="product-entry border">
                                <a href="<?php echo e(route('productDetails', [base64_encode($product->id)] )); ?>" class="prod-img">
                                    <button class="btn-sm btn-info">View Details</button>
                                    <img src="<?php echo e(asset('product_img').'/'.$product->image); ?>" class="img-fluid fixed-img-size product_img">
                                </a>
                                <div class="desc">
                                    <h2 class="text-uppercase"><a href="#"><?php echo e($product->name); ?></a></h2>
                                    <span class="price"><kbd>Brand:</kbd> <?php echo e($product->barnd); ?></span>
                                    <span class="price bg-success">In Stock <?php echo e($product->quantity); ?> piece</span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                <?php else: ?>
                    <h1 class="text-danger font-italic d-flex justify-content-center">Sorry No Product available !!!</h1>
                <?php endif; ?>
                
            </div>
            <span class="d-flex justify-content-center"><?php echo e($products->links()); ?></span>
        </div>
    </div>

    <div class="colorlib-partner">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 offset-sm-2 text-center colorlib-heading colorlib-heading-sm">
                    <h2>Brandes We Provide</h2>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $Brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($Brand->id==99): ?>
                        <?php continue; ?>
                    <?php endif; ?>
                    <div class="col partner-col text-center">
                        <img src="<?php echo e(asset('images').'/'.$Brand->image); ?>" class="img-fluid" alt="Free html4 bootstrap 4 template">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>