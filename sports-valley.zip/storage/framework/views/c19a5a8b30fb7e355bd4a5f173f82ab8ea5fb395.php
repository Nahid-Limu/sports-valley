<?php $__env->startSection('title', 'Sales'); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Content Row -->
  <div class="row">

    
  </div>

  <!-- Content Row -->

  <!-- Content Row  details-->
  <div class="row">


  </div>

  

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
// <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>