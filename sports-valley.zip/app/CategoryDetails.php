<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoryDetails extends Model
{
    //
}
